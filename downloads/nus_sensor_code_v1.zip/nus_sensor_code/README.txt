Sensor-network code by NUS High School of Mathematics and Science (Michael, Myat and Somnath),
copied from github.com/micg27/issf, folder Code (commit a253d66, 2026-11-27).
The phases match the sensor method PDF on the project website.
